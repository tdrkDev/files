ver 0.1.6
Resource Pack created by Max_Novik

____________________________________________________

Credits:
 
Original Bushy Leaves code written by Uncle Jam (YT page link): https://www.youtube.com/channel/UCfg9squuCoQvPJt5tCWjTOg
Bushy Leaves textures and code update to 1.13+ in this pack are done by Max_Novik

"Novik Pack" subtitle, as well as the new "Minecraft" title, created and provided by Ewan Howell (YT page link):
https://www.youtube.com/channel/UCW_TXyufamt-ByN704ks_4g

____________________________________________________

____________________________________________________

Custom Item Textures (OptiFine Required):

Fortunate Pickaxe: Diamond or Netherite Pickaxe, enchanted with Fortune and renamed containing the word "Fortune" in its name, will have a custom texture.

Iron Knife: Iron Sword renamed using words "Iron Knife" in its name will have a custom texture.

Heavy Mace: Iron Axe renamed using words "Heavy Mace" in its name will have a custom texture.

Green Alcohol: Glass Bottle, Water Bottle or any regular Potion renamed, containing the words "Green Alcohol" in its name, will have a custom texture. 
Note: This texture might be broken for potions with initially red/dark colors

____________________________________________________

____________________________________________________

Changelog (ver. 0.1.6):
- added Black Stained Glass texture
- added Brown Stained Glass texture
- added Orange Stained Glass texture
- added Green Stained Glass texture
- added Vertical Plank version for double Crimson Slab
- added Vertical Plank version for double Warped Slab
OptiFine Only:
- added random textures for Cows
- added connected textures for Bricks
- minor CTM tweaks